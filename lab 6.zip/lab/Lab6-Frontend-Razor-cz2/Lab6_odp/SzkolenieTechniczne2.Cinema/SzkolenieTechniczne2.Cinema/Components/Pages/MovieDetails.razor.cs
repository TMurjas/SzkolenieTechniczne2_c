﻿using MediatR;
using Microsoft.AspNetCore.Components;



using SzkolenieTechniczne2.Cinema.Domain.Query.Dtos;
using SzkolenieTechniczne2.Cinema.Domain.Query.Movie.GetMovieQuery;

using SzkolenieTechniczne2.Cinema.Models;



namespace SzkolenieTechniczne2.Cinema.Components.Pages
{
    public partial class MovieDetails : ComponentBase
    {
        [Inject]
        public NavigationManager Navigation { get; set; } = default!;

        [Inject]
        public IMediator MediatorService { get; set; } = default!;

        [Parameter]
        public long MovieId { get; set; }

        public MovieDetailsDto? Details;

        protected override async Task OnInitializedAsync()
        {
            Details = await MediatorService.Send(new GetMovieQuery(MovieId));
        }

        public async Task GoBack()
        {
            Navigation.NavigateTo("/movies");
        }


    }
}
