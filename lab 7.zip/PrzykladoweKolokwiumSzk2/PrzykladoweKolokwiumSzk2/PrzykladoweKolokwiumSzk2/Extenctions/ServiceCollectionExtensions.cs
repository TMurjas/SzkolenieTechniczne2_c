﻿using Microsoft.AspNetCore.Cors.Infrastructure;
using PrzykladoweKolokwiumSzk2.Trips.AddTrip;
using PrzykladoweKolokwiumSzk2.Trips.GetTrips;

namespace PrzykladoweKolokwiumSzk2.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddTripServices(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddDbContext<TripContextDb, TripContextDb>();
            serviceCollection.AddMediatR(cfg =>
            {
                cfg.RegisterServicesFromAssembly(typeof(AddTripCommand).Assembly);
                cfg.RegisterServicesFromAssembly(typeof(GetTripQuery).Assembly); ;
            });
            return serviceCollection;
        }
    }
}
