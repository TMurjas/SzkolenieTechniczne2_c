﻿using System.ComponentModel.DataAnnotations;

namespace PrzykladoweKolokwiumSzk2.Components.Pages
{
    public class AddTripFormModel
    {
        [Required] public string Name { get; set; } = string.Empty;
        [Required] public int CountryId { get; set; }
        public string Description { get; set; } = string.Empty;
        [Required] public DateOnly DateFrom { get; set; } = DateOnly.FromDateTime(DateTime.Today);
        [Required] public DateOnly DateTo { get; set; } = DateOnly.FromDateTime(DateTime.Today.AddDays(7));
        [Range(0, double.MaxValue)] public decimal PricePerPerson { get; set; }
        public string HotelName { get; set; } = string.Empty;
        public bool AllowsPets { get; set; }
    }
}
