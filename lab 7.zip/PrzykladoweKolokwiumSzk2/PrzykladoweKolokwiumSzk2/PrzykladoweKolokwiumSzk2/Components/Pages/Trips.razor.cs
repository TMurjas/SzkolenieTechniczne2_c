﻿using MediatR;
using Microsoft.AspNetCore.Components;
using PrzykladoweKolokwiumSzk2.Trips.GetCountries;
using PrzykladoweKolokwiumSzk2.Trips.GetTrips;

namespace PrzykladoweKolokwiumSzk2.Components.Pages
{
    public partial class Trips : ComponentBase
    {
        [Inject] public IMediator MediatorService { get; set; } = default!;
        private IReadOnlyList<TripDto>? trips;

        protected override async Task OnInitializedAsync()
            => trips = await Mediator.Send(new GetTripQuery());
    }
}
