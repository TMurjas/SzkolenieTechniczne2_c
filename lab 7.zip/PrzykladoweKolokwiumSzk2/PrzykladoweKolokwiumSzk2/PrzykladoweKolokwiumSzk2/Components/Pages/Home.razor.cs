﻿using MediatR;
using Microsoft.AspNetCore.Components;
using PrzykladoweKolokwiumSzk2.Trips.AddTrip;
using PrzykladoweKolokwiumSzk2.Trips.GetCountries;

namespace PrzykladoweKolokwiumSzk2.Components.Pages;

public partial class Home : ComponentBase
{
    [Inject] public IMediator MediatorService { get; set; } = default!;

    private AddTripFormModel model = new();
    private IReadOnlyList<CountryDto> countries = Array.Empty<CountryDto>();

    protected override async Task OnInitializedAsync()
    {
        countries = await MediatorService.Send(new GetCountriesQuery());
    }

    private async Task HandleValidSubmit()
    {
        var cmd = new AddTripCommand(
            model.Name,
            model.CountryId,
            model.Description,
            model.DateFrom,
            model.DateTo,
            model.PricePerPerson,
            model.HotelName,
            model.AllowsPets);

        await MediatorService.Send(cmd);
        Nav.NavigateTo("/trips");
    }

}
