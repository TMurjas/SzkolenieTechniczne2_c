﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrzykladoweKolokwiumSzk2.Trips.GetCountries;
public record TripDto(int Id, string Name,String Country,DateOnly Datefrom,DateOnly dateTo,Decimal PricePerPerson);
