﻿using MediatR;
using PrzykladoweKolokwiumSzk2.Trips.GetCountries;

namespace PrzykladoweKolokwiumSzk2.Trips.GetTrips
{
    public record GetTripQuery() : IRequest<List<TripDto>>
    {
    }
}
