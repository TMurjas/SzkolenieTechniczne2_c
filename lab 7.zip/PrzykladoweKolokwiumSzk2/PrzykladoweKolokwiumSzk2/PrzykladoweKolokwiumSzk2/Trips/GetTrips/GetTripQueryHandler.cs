﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PrzykladoweKolokwiumSzk2.Trips.GetCountries;
using PrzykladoweKolokwiumSzk2;
using PrzykladoweKolokwiumSzk2.Entities;
using PrzykladoweKolokwiumSzk2.Trips.GetTrips;


namespace PrzykladoweKolokwiumSzk2.Trips.GetCountries
{
    public class GetTripsQueryHandler : IRequestHandler<GetTripQuery, List<TripDto>>
    {

        private readonly TripContextDb context;
        public GetTripsQueryHandler(TripContextDb context) => this.context = context;


        public async Task<List<TripDto>> Handle(GetTripQuery q, CancellationToken ct)
        {
            return await context.Trips.Include(t => t.Country)
                              .Select(t => new TripDto
                              (
                                  t.Id,
                                  t.Name,
                                  t.Country.Name,
                                  t.DateFrom,
                                  t.DateTo,
                                  t.PricePerPerson
                              ))
                              .ToListAsync(ct);

        }

    }
}






