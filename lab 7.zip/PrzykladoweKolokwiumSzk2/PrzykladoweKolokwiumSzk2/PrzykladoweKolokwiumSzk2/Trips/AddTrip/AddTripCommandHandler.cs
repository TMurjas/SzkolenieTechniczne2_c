﻿using MediatR;
using PrzykladoweKolokwiumSzk2.Entities;
using Microsoft.EntityFrameworkCore;

namespace PrzykladoweKolokwiumSzk2.Trips.AddTrip
{
    public class AddTripCommandHandler : IRequestHandler<AddTripCommand, int>
    {
        private readonly TripContextDb context;
        public AddTripCommandHandler(TripContextDb context) => this.context = context;

        public async Task<int> Handle(AddTripCommand c, CancellationToken ct)
        {
            var trip = new Trip
            {
                Name = c.Name,
                CountryId = c.CountryId,
                Description = c.Description,
                DateFrom = c.DateFrom,
                DateTo = c.DateTo,
                PricePerPerson = c.PricePerPerson,
                HotelName = c.HotelName,
                AllowsPets = c.AllowsPets
            };

            context.Trips.Add(trip);
            await context.SaveChangesAsync(ct);
            return trip.Id;
        }
    }
}
