﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PrzykladoweKolokwiumSzk2.Trips.GetCountries;
using PrzykladoweKolokwiumSzk2;
using PrzykladoweKolokwiumSzk2.Entities;

namespace PrzykladoweKolokwiumSzk2.Trips.GetCountries
{
    public class GetCountriesQueryHandler : IRequestHandler < GetCountriesQuery, List<CountryDto>>
    {
        

        public TripContextDb context;

    public GetCountriesQueryHandler(TripContextDb context) => this.context = context;



       public async Task <List<CountryDto>> Handle(GetCountriesQuery q, CancellationToken ct)
       {
            return await context.Countries.OrderBy(c => c.Name)
                   .Select(c => new CountryDto(c.Id, c.Name))
                   .ToListAsync(ct);
       }

}
}




