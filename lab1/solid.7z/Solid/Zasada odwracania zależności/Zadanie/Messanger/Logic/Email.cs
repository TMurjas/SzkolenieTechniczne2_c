﻿namespace Messanger.Logic
{
    public class Email
    {

        public void SendEmail()
        {
            var _subject = "Test";
            var __content = "tresc";
            // implementacja
        }
    }
}