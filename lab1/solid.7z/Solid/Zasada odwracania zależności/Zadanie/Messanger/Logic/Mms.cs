﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Messanger.Logic
{
   public class Mms
    {
        public void SendMMS()
        {
            var _subject = "Test";
            var __content = "tresc";
            // implementacja
        }
    }
}
