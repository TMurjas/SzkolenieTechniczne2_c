﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Messanger.Logic
{
    public class Fax
    {
        public void SendFax()
        {
            var _subject = "Test";
            var __content = "tresc";
            // implementacja
        }
    }
}
