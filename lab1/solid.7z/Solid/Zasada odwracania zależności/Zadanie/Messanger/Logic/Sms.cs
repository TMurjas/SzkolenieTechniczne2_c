﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Messanger.Logic
{
   public class Sms
    {

        public void SendSMS()
        {
            var __content = "tresc";
            // implementacja
        }
    }
}
