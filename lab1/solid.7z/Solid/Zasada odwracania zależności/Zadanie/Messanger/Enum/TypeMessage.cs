﻿namespace Messanger.Enum
{
    public enum TypeMessage
    {
        Sms,
        Email,
        Fax,
        Mms
    }
}