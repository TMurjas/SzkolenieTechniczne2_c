﻿namespace SzkolenieTechniczne2.Cinema.Models
{
    public class CreateMovieFromModel

    {
        
        public string Name { get; set; }

        public int Year { get; set; }

        public int SeanceTime { get; set; }

        public long MovieCategoryId { get; set; }


    }
}
