﻿using MediatR;
using Microsoft.AspNetCore.Components;
using SzkolenieTechniczne2.Cinema.Models;
using SzkolenieTechniczne2.Cinema.Domain.Query.Dtos;
using SzkolenieTechniczne2.Cinema.Domain.Query.Movie.GetMovieCategorysQuery;
using SzkolenieTechniczne2.Cinema.Domain.Command;
using SzkolenieTechniczne2.Cinema.Domain.Command.Movie.Create;

namespace SzkolenieTechniczne2.Cinema.Components.Pages
{
    public partial class MovieCreate : ComponentBase
    {
        [Inject]
        public IMediator MediatorService { get; set; } = default;

        public CreateMovieFromModel Model { get; set; } = new();

        private List <MovieCategoryDto> Categories = new();

        private List<Result.Error> ValidationErrors = new();

        private string? SuccessMessage;

        protected override async Task OnInitializedAsync()
        {
            Categories = await MediatorService.Send(new GetMovieCategorysQuery());
        }

        private async Task HandleValidSubmit()
        {
            ValidationErrors.Clear();
            SuccessMessage = null;


            var command = new CreateMovieCommand(Model.Name, Model.Year, Model.SeanceTime, Model.MovieCategoryId);

            var resoult = await Mediator.Send(command);

            if (resoult.IsSuccess)
            {
                SuccessMessage = "Movie created Succesfully!";
                Model = new();
            }
            else {
                ValidationErrors = resoult.Errors.ToList();
            }


        }

    }
}
