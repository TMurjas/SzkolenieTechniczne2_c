﻿using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SzkolenieTechniczne2.Cinema.Common.Repositories;
using SzkolenieTechniczne2.Cinema.Domain.Query.Dtos;

namespace SzkolenieTechniczne2.Cinema.Domain.Query.Movie.GetMovieCategorysQuery
{
    public class GetMovieCategorysQueryHandler : IRequestHandler< GetMovieCategorysQuery, List<MovieCategoryDto>>
    {
        private readonly IMoviesRepository _repository;

        public GetMovieCategorysQueryHandler(IMoviesRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<MovieCategoryDto>> Handle(GetMovieCategorysQuery request, CancellationToken cancellationToken)
        {
            var categories = await _repository.GetMovieCategoriesAsync();

            return categories
                .Select(category => new MovieCategoryDto(category.Id, category.Name))
                .ToList();
        }
    }
}