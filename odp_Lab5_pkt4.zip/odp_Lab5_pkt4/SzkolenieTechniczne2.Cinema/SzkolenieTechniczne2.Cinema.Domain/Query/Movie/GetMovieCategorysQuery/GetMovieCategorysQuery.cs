﻿using MediatR;
using System;
using System.Collections.Generic;
using SzkolenieTechniczne2.Cinema.Domain.Query.Dtos;

namespace SzkolenieTechniczne2.Cinema.Domain.Query.Movie.GetMovieCategorysQuery
{
    public class GetMovieCategorysQuery : IRequest<List<MovieCategoryDto>>
    {
 
    }
}